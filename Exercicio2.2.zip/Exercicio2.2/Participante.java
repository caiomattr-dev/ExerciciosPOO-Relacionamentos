
public class Participante
{
    private String nome;
    private String telefone;
    
    public Participante(String nome, String telefone){
        this.nome = nome;
        this.telefone = telefone;
    }
    
    public String getNome(){
        return nome;
    }
    
    public boolean setNome(String nome){
        if(!nome.isBlank()){
            this.nome = nome;
            return true;
        }
        else
            return false;
    }
    
    public String getTelefone(){
        return telefone;
    }
    
    public boolean setTelefone(String telefone){
        if(!telefone.isBlank()){
            this.telefone = telefone;
            return true;
        }
        else
            return false;
    }
    
    
}
