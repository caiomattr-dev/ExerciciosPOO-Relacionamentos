import java.util.ArrayList;

public class Grupo{
    private String nome;
    private ArrayList<Participante> part;
    
    public Grupo(String nome){
        this.part = new ArrayList<Participante>();
        this.nome = nome;
    }
    
    public String getNome(){
        return nome;
    }
    
    public boolean setNome(String nome){
        if(!nome.isBlank()){
            this.nome = nome;
            return true;
        }
        else
            return false;
    }
    
    public void addParticipante(Participante part){
        this.part.add(part);
    }
    
    public void imprimirParticipantes(){
        for(int i = 0; i < part.size(); i++){
            System.out.println("Nome: " + part.get(i).getNome() + 
            ", telefone: " + part.get(i).getTelefone());
        
        }
        
    }
    
    public ArrayList<Participante> getParticipantes(){
        return part;
    }
}